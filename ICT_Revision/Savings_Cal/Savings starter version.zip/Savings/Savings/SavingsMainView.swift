//
//  SavingsMainView.swift
//  Savings
//
//  Created by Philip Trwoga on 14/10/2024.
//

import SwiftUI
import SwiftData

struct SavingsMainView: View {
    @FocusState private var fieldIsFocused: Bool
//your vars here
    @Environment(\.modelContext) private var modelContext
    var body: some View {

        VStack{
            //put your code here for the main UI
            //pattern is:
            //labels and textfields
            //button
            //payment output text

        }
    }
    //uncomment this function when ready
  /*  func calculateSavings(){
        var periodD = 0
        var annualInterestRateD = 0.0
        var initialAmountD = 0.0
        var monthlyContributionD = 0.0
        if !interest.isEmpty{
            annualInterestRateD = Double(interest)!
        }
        if !period.isEmpty{
            periodD = Int(period)!
        }
        if !initialAmount.isEmpty{
            initialAmountD = Double(initialAmount)!
        }
        if !monthlyContribution.isEmpty{
            monthlyContributionD = Double(monthlyContribution)!
        }
        
        let monthlyInterestRate = annualInterestRateD / 12 / 100
        let months = periodD * 12
        var totalSavings = initialAmountD
        
        for _ in 1...months {
            totalSavings += monthlyContributionD
            totalSavings += totalSavings * monthlyInterestRate
            print(totalSavings)
        }
        futureValue = String(format: "£%.2f",totalSavings)
   
        //insert a new model instance into the model context

        //now hide the keyboard

       
    }*/
    //uncomment this function when ready
 /*   func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    } */
}

#Preview {
    SavingsMainView()
}
