//
//  SavingsModel.swift
//  Savings
//
//  Created by Philip Trwoga on 16/10/2024.
//

import Foundation
import SwiftData

@Model class SavingsModel : Identifiable{

    //you vars here - hint use the names from the MainView
    //var futureValue:String
    //etc.



    init() {
      //  self.futureValue = futureValue
        //etc
    }
}
